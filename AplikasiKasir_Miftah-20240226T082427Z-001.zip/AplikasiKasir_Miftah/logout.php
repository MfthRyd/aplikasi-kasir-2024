<?php

	// memulai session
	session_start();

	//menghapus semua data session
	session_destroy();

	// tampilkan pesan logout
	echo '<script>alert("Anda Telah Logout");window.location="login.php"</script>';
?>
