<?php 
/*
  | Source Code Aplikasi Penjualan Barang Kasir dengan PHP & MYSQL
  | 
  | @package   : pos-kasir-php
  | @file	   : index.php 
  | @author    : fauzan1892 / Fauzan Falah
  | @copyright : Copyright (c) 2017-2021 Codekop.com (https://www.codekop.com)
  | @blog      : https://www.codekop.com/read/source-code-aplikasi-penjualan-barang-kasir-dengan-php-amp-mysql-gratis.html
  | 
  | 
  | 
  | 
 */

	@ob_start();
	// memulai session
	session_start();


	// cek apakah user sudah login
	if(!empty($_SESSION['admin'])){

		//jika ada maka pindah ke halaman home/dashboard
		require 'config.php';

		// mengambil data toko dari database
		include $view;
		$lihat = new view($config);
		$toko = $lihat -> toko();

		//  admin
			include 'admin/template/header.php';
			include 'admin/template/sidebar.php';

			// ambil data halaman saat ini dan import filenya
				if(!empty($_GET['page'])){
					include 'admin/module/'.$_GET['page'].'/index.php';
				}else{

					// tampilkan halaman home jika pagenya kosong
					include 'admin/template/home.php';
				}
			include 'admin/template/footer.php';
		// end admin
	}else{

		// pindah ke halaman login
		echo '<script>window.location="login.php";</script>';
		exit;
	}
?>

